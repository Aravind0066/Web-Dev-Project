//  LOAD DATA 
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";

//Login
function updateAuthUI() {
  let loginBtn = document.getElementById("loginBtn");
  let logoutBtn = document.getElementById("logoutBtn");

  if (!loginBtn || !logoutBtn) return;

  if (isLoggedIn) {
    loginBtn.style.display = "none";
    logoutBtn.style.display = "inline";
  } else {
    loginBtn.style.display = "inline";
    logoutBtn.style.display = "none";
  }
}

function logout() {
  localStorage.setItem("isLoggedIn", "false");
  window.location.href = "login.html";
}


let feedPosts = JSON.parse(localStorage.getItem("feedPosts")) || [];
let queries = JSON.parse(localStorage.getItem("queries")) || [];
let essentials = JSON.parse(localStorage.getItem("essentials")) || [
  "Night Canteen - Open till 1 AM"
];

let resources = JSON.parse(localStorage.getItem("resources")) || [
  "Classroom SJT-201 - Free",
  "Classroom AB-302 - Occupied",
  "WiFi - Library Block",
  "WiFi - Main Gate",
  "Restroom - Food Court",
  "Restroom - Academic Block"
];

let currentFilter = "all";

//  SAVE 
function saveData() {
  localStorage.setItem("feedPosts", JSON.stringify(feedPosts));
  localStorage.setItem("queries", JSON.stringify(queries));
  localStorage.setItem("essentials", JSON.stringify(essentials));
  localStorage.setItem("resources", JSON.stringify(resources));
}

//  FILTER 
function filterResources(type) {
  currentFilter = type;
  showResources();
}

//  RESOURCES 
function showResources() {
  let box = document.getElementById("resourceList");
  if (!box) return;

  box.innerHTML = "";

  for (let i = 0; i < resources.length; i++) {
    let item = resources[i].toLowerCase();

    if (
      currentFilter === "all" ||
      item.includes(currentFilter)
    ) {
      box.innerHTML += `<div class="card">${resources[i]}</div>`;
    }
  }
}

//  FEED 
function addPost() {
  let input = document.getElementById("feedInput");
  if (!input || input.value === "") return;

  feedPosts.push(input.value);
  input.value = "";
  saveData();
  showPosts();
}

function deletePost(index) {
  feedPosts.splice(index, 1);
  saveData();
  showPosts();
}

function showPosts() {
  let box = document.getElementById("feedList");
  if (!box) return;

  box.innerHTML = "";
  for (let i = 0; i < feedPosts.length; i++) {
    box.innerHTML += `
      <div class="post">
        ${feedPosts[i]}
        <br>
        <button onclick="deletePost(${i})">Delete</button>
      </div>
    `;
  }
}

//  QUERIES 
function addQuery() {
  let title = document.getElementById("queryTitle");
  let desc = document.getElementById("queryDesc");
  if (!title || title.value === "") return;

  queries.push(title.value + " - " + desc.value);
  title.value = "";
  desc.value = "";
  saveData();
  showQueries();
}

function deleteQuery(index) {
  queries.splice(index, 1);
  saveData();
  showQueries();
}

function showQueries() {
  let box = document.getElementById("queryList");
  if (!box) return;

  box.innerHTML = "";
  for (let i = 0; i < queries.length; i++) {
    box.innerHTML += `
      <div class="query-card">
        ${queries[i]}
        <br>
        <button onclick="deleteQuery(${i})">Delete</button>
      </div>
    `;
  }
}

//  ESSENTIALS 
function showEssentials() {
  let box = document.getElementById("essentialsList");
  if (!box) return;

  box.innerHTML = "";
  for (let i = 0; i < essentials.length; i++) {
    box.innerHTML += `<div class="essential-card">${essentials[i]}</div>`;
  }
}

//  PROFILE 
function showProfile() {
  let box = document.getElementById("profileInfo");
  if (!box) return;

  box.innerHTML = "<h3>Student</h3><p>Trust Score: 80</p>";
}

function showMyData() {
  let postBox = document.getElementById("myPosts");
  let queryBox = document.getElementById("myQueries");

  if (postBox) {
    postBox.innerHTML = "";
    for (let i = 0; i < feedPosts.length; i++) {
      postBox.innerHTML += `<div class="post">${feedPosts[i]}</div>`;
    }
  }

  if (queryBox) {
    queryBox.innerHTML = "";
    for (let i = 0; i < queries.length; i++) {
      queryBox.innerHTML += `<div class="query-card">${queries[i]}</div>`;
    }
  }
}

// admin check
function checkAdmin() {
  let role = localStorage.getItem("role");
  let adminBox = document.getElementById("adminControls");
  if (adminBox && role === "admin") {
    adminBox.style.display = "block";
  }
}

function addEssential() {
  let input = document.getElementById("newEssential");
  if (!input || input.value === "") return;

  essentials.push(input.value);
  input.value = "";
  saveData();
  showEssentials();
}



//  INIT 
document.addEventListener("DOMContentLoaded", function () {
  updateAuthUI();
  showResources();
  showPosts();
  showQueries();
  showEssentials();
  showProfile();
  showMyData();

  //temp
  checkAdmin();

});


